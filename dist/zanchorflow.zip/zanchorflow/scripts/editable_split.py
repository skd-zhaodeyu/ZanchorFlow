#!/usr/bin/env python3
import argparse
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter


def parse_names(value):
    if not value:
        return []
    return [item.strip() for item in value.split(",") if item.strip()]


NEIGHBORS = {
    4: ((1, 0), (-1, 0), (0, 1), (0, -1)),
    8: ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)),
}

# Only disregard a few nearly invisible pixels outside all ownership regions.
# Never threshold pixels within a region: detached details belong to the object.
MAX_RESIDUE_PIXELS = 4
MAX_RESIDUE_ALPHA = 8


def foreground_mask(alpha, threshold, close_radius):
    mask = alpha.point(lambda p: 255 if p > threshold else 0, mode="L")
    if close_radius <= 0:
        return mask
    size = close_radius * 2 + 1
    return mask.filter(ImageFilter.MaxFilter(size)).filter(ImageFilter.MinFilter(size))


def component_boxes(mask, min_area, connectivity):
    width, height = mask.size
    pixels = mask.load()
    seen = bytearray(width * height)
    components = []
    neighbors = NEIGHBORS[connectivity]

    for y in range(height):
        for x in range(width):
            idx = y * width + x
            if seen[idx] or pixels[x, y] == 0:
                continue

            stack = [(x, y)]
            seen[idx] = 1
            min_x = max_x = x
            min_y = max_y = y
            area = 0

            while stack:
                cx, cy = stack.pop()
                area += 1
                min_x = min(min_x, cx)
                max_x = max(max_x, cx)
                min_y = min(min_y, cy)
                max_y = max(max_y, cy)

                for dx, dy in neighbors:
                    nx = cx + dx
                    ny = cy + dy
                    if 0 <= nx < width and 0 <= ny < height:
                        nidx = ny * width + nx
                        if not seen[nidx] and pixels[nx, ny] != 0:
                            seen[nidx] = 1
                            stack.append((nx, ny))

            if area >= min_area:
                components.append({"area": area, "box": [min_x, min_y, max_x + 1, max_y + 1]})

    return components


def gap_between(a, b):
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    dx = max(0, max(ax1, bx1) - min(ax2, bx2))
    dy = max(0, max(ay1, by1) - min(ay2, by2))
    return max(dx, dy)


def union_box(a, b):
    return [
        min(a[0], b[0]),
        min(a[1], b[1]),
        max(a[2], b[2]),
        max(a[3], b[3]),
    ]


def box_area(box):
    return max(1, box[2] - box[0]) * max(1, box[3] - box[1])


def should_merge(a, b, max_gap, max_union_growth):
    if gap_between(a["box"], b["box"]) > max_gap:
        return False
    union = union_box(a["box"], b["box"])
    separate_area = box_area(a["box"]) + box_area(b["box"])
    return box_area(union) / max(1, separate_area) <= max_union_growth


def merge_fragments(components, max_gap, max_union_growth):
    if max_gap <= 0:
        return components
    merged = [dict(component, merged_count=1) for component in components]
    changed = True
    while changed:
        changed = False
        for i in range(len(merged)):
            for j in range(i + 1, len(merged)):
                if not should_merge(merged[i], merged[j], max_gap, max_union_growth):
                    continue
                merged[i] = {
                    "area": merged[i]["area"] + merged[j]["area"],
                    "box": union_box(merged[i]["box"], merged[j]["box"]),
                    "merged_count": merged[i]["merged_count"] + merged[j]["merged_count"],
                }
                del merged[j]
                changed = True
                break
            if changed:
                break
    return merged


def sort_components(components, mode):
    if mode == "area":
        return sorted(components, key=lambda item: item["area"], reverse=True)
    if mode == "y":
        return sorted(components, key=lambda item: (item["box"][1], item["box"][0]))
    return sorted(components, key=lambda item: (item["box"][0], item["box"][1]))


def extract_component_asset(image, box, pad, square, region_box=None):
    width, height = image.size
    left, top, right, bottom = box
    bounds = region_box or [0, 0, width, height]
    left = max(bounds[0], left - pad)
    top = max(bounds[1], top - pad)
    right = min(bounds[2], right + pad)
    bottom = min(bounds[3], bottom + pad)
    component_image = image.crop((left, top, right, bottom))
    if not square:
        return component_image, [left, top, right, bottom]

    side = max(component_image.size)
    canvas = Image.new("RGBA", (side, side), (0, 0, 0, 0))
    canvas.alpha_composite(
        component_image,
        ((side - component_image.size[0]) // 2, (side - component_image.size[1]) // 2),
    )
    return canvas, [left, top, right, bottom]


def region_components(image, path, warnings=None):
    """Validate ownership regions before cropping, including faint detached pixels."""
    data = json.loads(Path(path).read_text())
    regions = data.get("regions") if isinstance(data, dict) else None
    if not isinstance(regions, list) or not regions:
        raise SystemExit("--regions requires a nonempty regions list")
    alpha = image.getchannel("A")
    uncovered = alpha.copy()
    components = []
    names = set()
    for region in regions:
        if not isinstance(region, dict):
            raise SystemExit("Each region must be an object")
        name, box = region.get("name"), region.get("box")
        if (not isinstance(name, str) or not name or name in {".", ".."}
                or any(c in name for c in ("/", "\\", "\x00"))):
            raise SystemExit("Region name must be a safe filename component")
        filename = name if name.lower().endswith(".png") else name + ".png"
        if filename.casefold() in names:
            raise SystemExit("Region names must be unique")
        names.add(filename.casefold())
        if (not isinstance(box, list) or len(box) != 4
                or any(type(v) is not int for v in box)):
            raise SystemExit("Region box must be [x, y, width, height] integer pixels")
        x, y, width, height = box
        if x < 0 or y < 0 or width <= 0 or height <= 0 or x + width > image.width or y + height > image.height:
            raise SystemExit(f"Region {name} is outside the image or has nonpositive size")
        bounds = [x, y, x + width, y + height]
        for prior in components:
            a, b, c, d = prior["region_box"]
            if max(x, a) < min(x + width, c) and max(y, b) < min(y + height, d):
                raise SystemExit(f"Region {name} overlaps another region")
        local = alpha.crop(bounds)
        bbox = local.getbbox()
        if bbox is None:
            raise SystemExit(f"Region {name} contains no foreground")
        if bbox[0] == 0 or bbox[1] == 0 or bbox[2] == width or bbox[3] == height:
            raise SystemExit(f"Region {name} foreground touches its boundary; expand the region")
        uncovered.paste(0, bounds)
        components.append({"name": filename, "region_box": bounds,
                           "box": [x + bbox[0], y + bbox[1], x + bbox[2], y + bbox[3]],
                           "area": sum(local.histogram()[1:])})
    uncovered_box = uncovered.getbbox()
    if uncovered_box is not None:
        pixel_count = sum(uncovered.histogram()[1:])
        max_alpha = uncovered.getextrema()[1]
        if pixel_count > MAX_RESIDUE_PIXELS or max_alpha > MAX_RESIDUE_ALPHA:
            raise SystemExit(f"Regions leave foreground uncovered: {list(uncovered_box)}")
        # The blank perimeter enforced above separates these pixels from every
        # owned object, including any faint stroke connected to its main body.
        warning = {"code": "ignored_faint_residue", "pixel_count": pixel_count,
                   "max_alpha": max_alpha, "box": list(uncovered_box)}
        if warnings is not None:
            warnings.append(warning)
    return components


def write_contact_sheet(items, out_path):
    if not items:
        return
    thumb = 180
    label_h = 28
    cols = min(5, len(items))
    rows = (len(items) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * thumb, rows * (thumb + label_h)), "white")
    draw = ImageDraw.Draw(sheet)
    for index, item in enumerate(items):
        row, col = divmod(index, cols)
        preview = item["image"].copy()
        preview.thumbnail((thumb - 16, thumb - 16))
        x = col * thumb + (thumb - preview.width) // 2
        y = row * (thumb + label_h) + (thumb - preview.height) // 2
        checker = Image.new("RGB", preview.size, "#f4f4f4")
        checker.paste(preview, mask=preview.getchannel("A"))
        sheet.paste(checker, (x, y))
        draw.text((col * thumb + 8, row * (thumb + label_h) + thumb), item["name"], fill="black")
    sheet.save(out_path)



def split_batch(src,out_dir,region_path,manifest,pad=24):
    """Partial object failures are explicit; ambiguous ownership blocks acceptance."""
    import hashlib
    src=Path(src).resolve();out_dir=Path(out_dir).resolve();manifest=Path(manifest).resolve()
    if pad<0:raise ValueError('Negative padding')
    if out_dir.exists() or manifest.exists():raise ValueError('Batch output must be a new directory and report')
    data=json.loads(Path(region_path).read_text(encoding='utf-8'));objects=data.get('objects')
    if not isinstance(objects,list) or not objects:raise ValueError('Batch objects required')
    image=Image.open(src).convert('RGBA');alpha=image.getchannel('A');uncovered=alpha.copy()
    names=set();keys=set();regions=[];assets=[];pending=[]
    for item in objects:
        key=item.get('job_key');name=item.get('name',key)
        if not isinstance(key,str) or not key or key in keys:raise ValueError('Unique batch job_key required')
        keys.add(key)
        if not isinstance(name,str) or not name or name in ('.','..') or any(c in name for c in ('/','\\','\x00',':','<','>','\"','|','?','*')) or name.rstrip(' .')!=name or name.split('.')[0].upper() in {'CON','PRN','AUX','NUL',*(f'COM{i}' for i in range(1,10)),*(f'LPT{i}' for i in range(1,10))}:raise ValueError('Safe asset name required')
        filename=name if name.lower().endswith('.png') else name+'.png'
        if filename.casefold() in names:raise ValueError('Unique asset names required')
        names.add(filename.casefold());box=item.get('box');entry={'job_key':key,'status':'failed'}
        if box is None:
            entry['failure']='missing: no actual region assigned';assets.append(entry);continue
        if not isinstance(box,list) or len(box)!=4 or any(type(v) is not int for v in box):raise ValueError('Integer [x,y,width,height] region required')
        x,y,w,h=box
        if min(x,y)<0 or min(w,h)<=0 or x+w>image.width or y+h>image.height:raise ValueError('Batch region outside image')
        bounds=[x,y,x+w,y+h]
        for a,b,c,d in regions:
            if max(x,a)<min(x+w,c) and max(y,b)<min(y+h,d):raise ValueError('Ambiguous overlapping batch regions')
        regions.append(bounds);uncovered.paste(0,bounds);local=alpha.crop(bounds);bbox=local.getbbox();entry['region_box']=bounds
        if bbox is None:entry['failure']='empty region'
        elif bbox[0]==0 or bbox[1]==0 or bbox[2]==w or bbox[3]==h:entry['failure']='foreground touches ownership boundary'
        else:
            crop=[x+bbox[0],y+bbox[1],x+bbox[2],y+bbox[3]]
            asset,padded=extract_component_asset(image,crop,pad,False,bounds)
            entry.update(status='extracted',box=crop,padded_box=padded,size=list(asset.size));pending.append((filename,asset,entry))
        assets.append(entry)
    errors=[];warnings=[]
    if uncovered.getbbox():
        count=sum(uncovered.histogram()[1:]);maximum=uncovered.getextrema()[1]
        if count>MAX_RESIDUE_PIXELS or maximum>MAX_RESIDUE_ALPHA:errors.append({'code':'unowned_foreground','box':list(uncovered.getbbox()),'pixel_count':count})
        else:warnings.append({'code':'ignored_faint_residue','pixel_count':count,'max_alpha':maximum})
    out_dir.mkdir(parents=True,exist_ok=False)
    for name,asset,entry in pending:
        dest=out_dir/name
        with dest.open('xb') as f:asset.save(f,format='PNG')
        entry.update(path=str(dest),sha256=hashlib.sha256(dest.read_bytes()).hexdigest())
    result={'batch_mode':True,'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'regions_source':str(Path(region_path).resolve()),'regions_sha256':hashlib.sha256(Path(region_path).read_bytes()).hexdigest(),'sheet_safe':not errors,'global_errors':errors,'warnings':warnings,'assets':assets}
    manifest.parent.mkdir(parents=True,exist_ok=True)
    with manifest.open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2)
    return result

def main():
    parser = argparse.ArgumentParser(description="Split a transparent asset sheet into component PNG files.")
    parser.add_argument("--input", required=True, help="RGBA asset sheet after chroma-key removal")
    parser.add_argument("--out-dir", required=True, help="Directory for split PNG assets")
    parser.add_argument("--regions", help="JSON {regions: [{name, box: [x,y,width,height]}]}; preserves all alpha within each region")
    parser.add_argument("--names", help="Comma-separated output names in sorted component order")
    parser.add_argument("--sort", choices=["x", "y", "area"], default="x")
    parser.add_argument("--threshold", type=int, default=20, help="Alpha threshold for foreground pixels")
    parser.add_argument("--min-area", type=int, default=1000, help="Minimum connected area to keep")
    parser.add_argument("--connectivity", type=int, choices=[4, 8], default=8)
    parser.add_argument("--close-radius", type=int, default=3, help="Small morphology close radius for broken strokes")
    parser.add_argument("--merge-gap", type=int, default=18, help="Merge nearby fragments within this pixel gap; 0 disables")
    parser.add_argument("--merge-union-growth", type=float, default=2.4, help="Maximum union-box growth allowed when merging fragments")
    parser.add_argument("--pad", type=int, default=24)
    parser.add_argument("--limit", type=int, help="Maximum number of components to write")
    parser.add_argument("--square", action="store_true", help="Place each extracted asset on a transparent square canvas")
    parser.add_argument("--manifest", help="Optional JSON report path for component boxes and outputs")
    parser.add_argument("--contact-sheet", help="Optional contact sheet image for visual QA")
    parser.add_argument("--batch", action="store_true", help="Explicit partial-failure mode; --regions uses objects with job_key/name/box")
    args = parser.parse_args()
    if args.batch:
        if not args.regions or not args.manifest or args.names or args.limit or args.square:
            parser.error("--batch requires --regions and --manifest; no --names/--limit/--square")
        try:
            result=split_batch(args.input,args.out_dir,args.regions,args.manifest,args.pad)
        except (ValueError,OSError,KeyError,TypeError) as exc:
            parser.error(str(exc))
        print(json.dumps(result,ensure_ascii=False,indent=2))
        return

    src = Path(args.input)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    image = Image.open(src).convert("RGBA")
    if args.pad < 0:
        raise SystemExit("--pad must be nonnegative")
    warnings = []
    if args.regions:
        if args.names or args.limit:
            raise SystemExit("--regions cannot be combined with --names or --limit")
        components = region_components(image, args.regions, warnings)
    else:
        mask = foreground_mask(image.getchannel("A"), args.threshold, args.close_radius)
        components = component_boxes(mask, 1, args.connectivity)
        components = merge_fragments(components, args.merge_gap, args.merge_union_growth)
        components = [item for item in components if item["area"] >= args.min_area]
        components = sort_components(components, args.sort)
        if args.limit:
            components = components[: args.limit]

    names = parse_names(args.names)
    if names and len(names) != len(components):
        raise SystemExit(f"--names supplied {len(names)} names, but detected {len(components)} components")

    if args.regions:
        for component in components:
            if (out_dir / component["name"]).resolve() == src.resolve():
                raise SystemExit("A region output must not overwrite the input sheet")

    outputs = []
    contact_items = []
    for index, component in enumerate(components, start=1):
        name = component.get("name") or (names[index - 1] if names else f"asset_{index:02d}.png")
        if not name.lower().endswith(".png"):
            name += ".png"
        component_image, padded_box = extract_component_asset(image, component["box"], args.pad, args.square, component.get("region_box"))
        out_path = out_dir / name
        component_image.save(out_path)
        entry = {
            "path": str(out_path),
            "source": str(src),
            "box": component["box"],
            "padded_box": padded_box,
            "area": component["area"],
            "merged_count": component.get("merged_count", 1),
            "size": list(component_image.size),
        }
        if "region_box" in component:
            entry["region_box"] = component["region_box"]
        outputs.append(entry)
        contact_items.append({"name": name, "image": component_image})
        print(f"{name}: box={component['box']} area={component['area']} size={component_image.size}")

    for warning in warnings:
        print(f"Warning: {json.dumps(warning)}")
    if args.manifest:
        report = {"source": str(src), "assets": outputs}
        if warnings:
            report["warnings"] = warnings
        Path(args.manifest).write_text(json.dumps(report, ensure_ascii=False, indent=2))
    if args.contact_sheet:
        write_contact_sheet(contact_items, Path(args.contact_sheet))


if __name__ == "__main__":
    main()
